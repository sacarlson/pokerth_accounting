
nohup pokerth &
sleep 3

cd /usr/share/pokerthacc
./pokerth_accounting.rb
