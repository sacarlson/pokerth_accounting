# pokerth_accounting
A proof of concept to add real money P2P poker transactions to the popular  pokerth texas holdem poker game

for details explaining the system with details of how it works and how to use it, see the wiki at:
https://github.com/sacarlson/pokerth_accounting/wiki

There is also a pdf file that includes screen shots that is included in the package that can be seen here:
https://github.com/sacarlson/pokerth_accounting/blob/master/instruction_manual.pdf

The pdf file above includes details of what is needed to install and how to operate the system.

Note: This system works not only on real value assets and currency, but is also being tested with worthless CHP crypto currency transacted on Stellar testnet, that is distributed as a free score keeping method for Pokerth.

