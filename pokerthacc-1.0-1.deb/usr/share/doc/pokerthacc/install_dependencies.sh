sudo apt-get install ruby-full sqlite3 libsqlite3-dev ruby-sqlite3 build-essential sqlitebrowser pokerth libttspico-utils
sudo gem install sys-proctable
sudo gem install rest-client
sudo gem install json
sudo gem install sqlite3
