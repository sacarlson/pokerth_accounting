sqlitebrowser /home/sacarlson/.pokerth/accounts/account_log.pdb
