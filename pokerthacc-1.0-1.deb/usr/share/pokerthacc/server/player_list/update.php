<?php
$cmd = "ruby ./fund_accounts.rb";
echo system($cmd);
?>
